# SlabRail CAD files (SlabRail_CAD.zip)

SlabRail: graded-slab batch scanner. Rev A, draft for design review. Designed, CAD-checked and simulated. Not yet built. Package date 2026-10-27.

Built from git commit `8e461f3` (https://github.com/Icevyy14/codex/tree/8e461f3bbb63fc7d6d6bf3b57694a686b28a424d/psa-slab-scanner).

Every file here is generated from the CadQuery model. The model's Python sources, and the commands that regenerate these files, are in the repo, not in this zip: https://github.com/Icevyy14/codex/tree/claude/psa-slab-batch-scanner-w2e2m9/psa-slab-scanner/cad (described in `cad/README.md`, which is also in this zip). Do not edit the exports by hand.

The files keep their repo paths (relative to the `psa-slab-scanner/` folder) under `SlabRail_CAD/`.

## What is in this zip

| Files | What they are |
|---|---|
| **Assemblies, STEP**: 4 files in `cad/out/assembly/`: slabrail_home, slabrail_pick_bottom, slabrail_carry, slabrail_station | The whole machine, one file per pose: one named, coloured solid per part, in machine coordinates. Measure on these. |
| **Assemblies, GLB**: `cad/out/assembly/slabrail_home.glb`, `cad/out/assembly/slabrail_carry.glb` | The same assemblies as meshes, for viewing only (glTF: metres, Y up). |
| **Printed parts, STEP**: 25 files in `cad/out/printed/`: awl_adapter, belt_clamp, camera_bracket, carry_flag_arm, carry_sensor_mount, drill_template, fill_gauge, gate_post_L, gate_post_R, head_foot, phase0_base, phase0_occluder_mount, phase0_top, phase0_tray, station_mount, x_bracket, x_bumper_L, x_idler_mount, x_idler_slider, x_motor_mount, x_switch_mount, z_end_cap, z_motor_mount, z_plate, z_switch_mount | One solid per printed part, in print orientation (not in machine coordinates). |
| **Printed parts, STL**: 25 files in `cad/out/printed/`: awl_adapter, belt_clamp, camera_bracket, carry_flag_arm, carry_sensor_mount, drill_template, fill_gauge, gate_post_L, gate_post_R, head_foot, phase0_base, phase0_occluder_mount, phase0_top, phase0_tray, station_mount, x_bracket, x_bumper_L, x_idler_mount, x_idler_slider, x_motor_mount, x_switch_mount, z_end_cap, z_motor_mount, z_plate, z_switch_mount | The same parts for the slicer, already in print orientation. |
| **Print list**: `cad/out/printed/print_list.json` | Per printed part: quantity, bounding box, volume (cm³) and a print note. |
| **Cut list**: `cad/out/cut_list.csv` | Stock cut to length, with quantities. |
| **Probe flag blank**: `cad/out/probe_flag_blank.dxf`, `cad/out/probe_flag_blank.svg` | Flat outline of the bent aluminium probe flag (DXF) and its dimensioned drawing (SVG, 1:1 at 100 %). |
| **Geometry checks**: `cad/out/checks.txt` | Output of the last geometry-check run: one line per check. |
| **Drawing set**: `cad/out/drawings/SlabRail_drawings.pdf` | Drawing set (D-00 to D-17, ANSI B), 18 sheets: the dimensioned drawings, Rev A, draft for design review. |
| **Bill of materials**: `docs/BOM.csv` | The line-by-line parts list with links (explained in docs/BOM.md in the repo). |
| **CAD notes**: `cad/README.md` | The full CAD README as it is in the repo. It also describes the Python sources and commands, which are in the repo, not in this zip. |

## Units

- Millimetres everywhere: the Python, the STEP, STL and DXF files, `print_list.json` and `cut_list.csv`.
  Volumes in `print_list.json` are cm³.
- The STEP files are AP214 (`AUTOMOTIVE_DESIGN`), written by Open CASCADE. The DXF declares millimetres
  (`$INSUNITS` 4).
- The GLB files are the only exception. glTF expects metres and +Y up, so their root node scales by 0.001 and turns the
  model Z-up to Y-up. The mesh data inside is still CAD millimetres on the CAD axes (see `export_glb.py`).

## Coordinate system and origin

Taken from `layout.py` and confirmed by measuring the model:

| Axis | Direction | Zero |
|---|---|---|
| X | Left to right along the pocket row (the gantry beam's direction). | The left interior edge of cell 0, which is the inside surface of the leftmost guide rods (`rod_00` spans X −8 to 0). |
| Y | Front (−) to back (+). The operator stands at −Y; slab labels point to −Y. | The pocket row's centre line, which is also the cup's fixed Y. There is no Y axis. |
| Z | Up. | **The top surface of the pocket floor pads.** |

Reference heights and positions, measured on the model:

- Pad top Z 0, bed (plywood) top Z −3, bed underside −21, base-rail underside −41, feet bottom −49.
- The 14 cells are 92 mm apart (84 mm pocket + 8 mm wall line). Cell 7 is the read station (X 686, no pocket), so pocket
  0 is at X 42, pocket 6 at 594, pocket 7 at 778, and pocket 12, the exception pocket, at 1238.
- The X beam's front face (the rail mounting face) is at Y 107, and its centre is at Z 400.
- Machine coordinates use the same frame. **Machine X** is the X of the suction-cup axis. **c** (machine Z) is the height
  of the cup face above Z 0. In the `home` assembly the cup face is at Z 248, which is c = 248.
- Overall envelope in every pose: X −78 to 1358, Y −117.5 to 172, Z −49 to 671. The frame and the Z motor set it. The Z
  motor rides on the X carriage but does not move in Z.

## Poses

`build.POSES` defines four assembly poses. Each one is a call to `model.machine(cup_x, c, held_slab, fill)`.
"Full" means 30 slabs (`STACK_MAX`).

| Pose | Cup X | c | Slab on the cup | Stacks | What it shows |
|---|---|---|---|---|---|
| `home` | 134 (pocket 1) | 248 (`C_SAFE_EMPTY`, travel height) | no | start of a run: pockets 1–11 full, 0 and 12 empty | The machine as loaded. This is not the homing position: the X home switch trips at cup X 19 and the Z top switch at c = 258. |
| `pick_bottom` | 1146 (pocket 11) | 6.6 (one slab, `SLAB_T`) | no | pockets 1–10 full, pocket 11 holds 1, 0 and 12 empty | The lowest pick: the cup on the last slab of a pocket between full neighbours. |
| `carry` | 88 (between pocket 0 at 42 and pocket 1 at 134) | 248 (`C_SAFE_LOADED`) | yes | pocket 0 holds 12, pocket 1 holds 17, pockets 2–11 full | Loaded travel over the rods. |
| `station` | 686 (station, cell 7) | 171.6 (`STATION_READ_C`) | yes | pockets 0–2 full, pocket 3 holds 12, pocket 4 empty, pockets 5–11 full | Reading the slab's front label over the upward camera. The slab's front is 140 mm above the station lens. |

With nothing pressing on it, the cup hangs 2 mm (`CUP_HANG`) below c. A held slab's underside is therefore at
c − 2 − 6.6. `checks.py` uses many more poses than these four: every pick, place, travel height, hard stop and the
Phase 0 jig.

_The three sections above are copied from `cad/README.md`. Names such as `layout.py` or `build.POSES` there refer to the CAD sources in the repo._
